/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array_saul_11;

import java.util.*;

/**
 *
 * @author Raven
 */
public class Array_Saul_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int[][] array = new int[15][15];
        int soma = 0;
        int media = 0;

        for (int i = 0; i < array.length; i++) { //Preencher o Array com números aleatorios
            for (int j = 0; j < array[i].length; j++) {
                array[i][j] = (int) (Math.random() * 99 + 1);
            }
        }

        for (int i = 0; i < array.length; i++) { //Exibir o Array 
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }

        for (int[] i : array) { //Somatorio do Array
            for (int num : i) {
                soma += num;
                media = soma+= num;
                media = media/225;
            }
        }


        System.out.println("");
        System.out.println("Somatoria do Array: ");
        System.out.println(soma);
        System.out.println("Média Aritmética do Array: ");
        System.out.println(media);    
        
    }

}
