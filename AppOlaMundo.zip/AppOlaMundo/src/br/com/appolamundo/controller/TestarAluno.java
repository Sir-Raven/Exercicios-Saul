package br.com.appolamundo.controller;

import br.com.appolamundo.model.Aluno;

public class TestarAluno {
    public static void main(String[] args) {
        Aluno primeiroPeriodo = new Aluno();
        
        primeiroPeriodo.setNome("José da Silva");
        primeiroPeriodo.setMatricula(1222233);
        
        System.out.println("Nome: " + primeiroPeriodo.getNome());
        System.out.println("Matricula: " + primeiroPeriodo.getMatricula());
        
    }
    
}
