/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.appolamundo.controller;

import br.com.appolamundo.model.Veiculo;
import java.util.Scanner;

/**
 *
 * @author Raven
 */
public class TestaVeiculo {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Veiculo Oficina = new Veiculo();

        String ModeloUm, ModeloDois, ModeloTres;
        String PlacaUm, PlacaDois, PlacaTres;
        String CorUm, CorDois, CorTres;
        int AnoUm, AnoDois, AnoTres;

        System.out.println("Digite a Cor do Carro: ");
        CorUm = input.nextLine();
        Oficina.setCor(CorUm);
        System.out.println("Digite o Modelo do Carro: ");
        ModeloUm = input.nextLine();
        Oficina.setModelo(ModeloUm);
        System.out.println("Digite a Placa do Carro: ");
        PlacaUm = input.nextLine();
        Oficina.setPlaca(PlacaUm);
        System.out.println("Digite o Ano do Carro: ");
        AnoUm = input.nextInt();
        Oficina.setAno(AnoUm);
        
        System.out.println("\\\\\\\\\\\\\\\\\\\\");

        System.out.println("Digite a Cor do Carro: ");
        CorDois = input.nextLine();
        Oficina.setCor(CorDois);
        System.out.println("Digite o Modelo do Carro: ");
        ModeloDois = input.nextLine();
        Oficina.setModelo(ModeloDois);
        System.out.println("Digite a Placa do Carro: ");
        PlacaDois = input.nextLine();
        Oficina.setPlaca(PlacaDois);
        System.out.println("Digite o Ano do Carro: ");
        AnoDois = input.nextInt();
        Oficina.setAno(AnoDois);
        
        System.out.println("\\\\\\\\\\\\\\\\\\\\");

        System.out.println("Digite a Cor do Carro: ");
        CorTres = input.nextLine();
        Oficina.setCor(CorTres);
        System.out.println("Digite o Modelo do Carro: ");
        ModeloTres = input.nextLine();
        Oficina.setModelo(ModeloTres);
        System.out.println("Digite a Placa do Carro: ");
        PlacaTres = input.nextLine();
        Oficina.setPlaca(PlacaTres);
        System.out.println("Digite o Ano do Carro: ");
        AnoTres = input.nextInt();
        Oficina.setAno(AnoTres);
        
        System.out.println("\\\\\\\\\\\\\\\\\\\\");

        Oficina.showCor(CorUm);
        Oficina.showModelo(ModeloUm);
        Oficina.showPlaca(PlacaUm);
        Oficina.showAno(AnoUm);
        System.out.println("");
        Oficina.showCor(CorDois);
        Oficina.showModelo(ModeloDois);
        Oficina.showPlaca(PlacaDois);
        Oficina.showAno(AnoDois);
        System.out.println("");
        Oficina.showCor(CorTres);
        Oficina.showModelo(ModeloTres);
        Oficina.showPlaca(PlacaTres);
        Oficina.showAno(AnoTres);

    }

}
