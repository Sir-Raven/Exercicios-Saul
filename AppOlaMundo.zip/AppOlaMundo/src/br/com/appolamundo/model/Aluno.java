package br.com.appolamundo.model;

public class Aluno {

    private String nome;
    private int matricula;

    public Aluno(){
        
    }
    
    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return this.matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
}
