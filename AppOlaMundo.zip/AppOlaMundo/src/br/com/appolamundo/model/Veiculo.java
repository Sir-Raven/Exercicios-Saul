/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.appolamundo.model;

/**
 *
 * @author Raven
 */
public class Veiculo {

    private String Placa;
    private String Cor;
    private String Modelo;
    private int Ano;

    public int getAno() {
        return Ano;
    }

    public void setAno(int Ano) {
        this.Ano = Ano;
    }
    
    public void showAno(int Ano) {
        System.out.println(getAno() + " É o Ano do Carro.");
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }
    
    public void showPlaca(String Placa) {
        System.out.println(getPlaca() + " É a Placa do Carro.");
    }

    public String getCor() {
        return Cor;
    }

    public void setCor(String Cor) {
        this.Cor = Cor;
    }
    
    public void showCor(String Cor) {
        System.out.println(getCor() + " É a Cor do Carro.");
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }
    
    public void showModelo(String Modelo) {
        System.out.println(getModelo() + " É o Modelo do Carro.");
    }

}
